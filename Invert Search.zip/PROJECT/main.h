#ifndef MAIN_H
#define MAIN_H
#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include <ctype.h>



#define FAILURE -1
#define SUCCESS 0
#define FILE_EMPTY -2
#define FILE_NOT_EXIST -3
#define FNAME_SIZE  20
#define WORD_SIZE 15



// File names List
typedef struct file_list
{
	char f_name[FNAME_SIZE];
	struct file_list *link;
}Flist;

typedef struct sub_node
{
	int word_count;
	char file_name[FNAME_SIZE];
	struct sub_node *s_link;
}sub_n;
typedef struct main_node
{
	char word[WORD_SIZE];
	int file_count;
	struct main_node *main_link;
	struct sub_node *sub_link;
}main_n;


int file_validate_filelist( Flist **head,char *argv[]);

int open_files_checkfile(char *file_name);

int insert_file_list(Flist **head,char *filename);

//void print_database(main_n **arr);

int insert_main_node(main_n **arr,char *data);

int create_database(Flist *head, main_n **arr);

int read_filenames(Flist *f_head , main_n **arr ,char *filename);

int check_and_update_wordcount(main_n **head,char *filename);

int display_database(main_n *arr[]);

int search_database(main_n *arr,char *word);

int save_database(main_n *head[]);

int update_validation(main_n **arr,char file[50]);

#endif
