#include "main.h"

int save_database(main_n *head[])
{
	char file_name[FNAME_SIZE];
	printf("Enter the filename you want save in database\n");
	scanf("%s" , file_name);

	FILE *new_fptr = fopen(file_name,"w");

	if(new_fptr == NULL)
	{
		printf("Error : File not available\n");
		return 0;
	}



	for(int index = 0; index < 26 ; index++)
	{
		main_n * m_temp = head[index];

		while(m_temp != NULL)
		{
			fprintf(new_fptr,"#%d;%s;%d",index , m_temp -> word , m_temp -> file_count);

			sub_n *s_temp = m_temp -> sub_link;

			while(s_temp != NULL)
			{
				fprintf(new_fptr,";%s;%d",s_temp -> file_name , s_temp -> word_count);
				s_temp = s_temp -> s_link;
			}

			fprintf(new_fptr,"#\n");

			m_temp = m_temp -> main_link;
		}

	}

	printf("\nDatabase saved Successfully in %s\n", file_name);
	fclose(new_fptr);
}

