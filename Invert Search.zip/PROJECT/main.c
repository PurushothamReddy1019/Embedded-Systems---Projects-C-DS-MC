#include<stdio.h>
#include "main.h"
int main(int argc,char *argv[])
{
	if(argc == 1)
	{
		printf("please pass atleast one more argument.\n");
		printf("\n./a.out f1.txt f2.txt....\n");
	}
	else
	{
		Flist *head = NULL;
		int database = 0;
		int flag = 0;

		char loop;

		main_n *arr[27] = {NULL};


		if(file_validate_filelist(&head,argv) == SUCCESS)
		{
			printf("\nFile Validation is Completed and Filenames are Added into list\n");
		}
		else
		{
			printf("\n File Validation is Failed\n");
		}


		do
		{		printf("\n1.Create Database\n2.Display Database\n3.Search Database\n4.Save Database\n5.Update database\n");
			int choice;
			printf("\nEnter the choice : ");
			scanf("%d",&choice);
			switch(choice)
			{
				case 1 :
					{
						if(flag == 0)
						{
							if(create_database(head,arr) == SUCCESS)
							{
								printf("\nDatabase creation was successful.\n");
								database = 1;
							}
							else
							{
								printf("\nDatabase creation failed\n");
							}
						}
						else
						{
							printf("\nERROR : Database should not be created after Updated database\n");
						}

						//print_database(arr);

						break;
					}
				case 2:
					{
						if(database == 1)
						{
							display_database(arr);
						}
						else
						{
							printf("--------------> DATABASE IS EMPTY <----------------\n");
						}
						break;
					}
				case 3:
					{
						printf("Enter the word to Search: ");

						char word[WORD_SIZE];

						scanf("%s",word);

						if(search_database(arr[tolower(word[0]) % 97] , word) != SUCCESS)
						{
							printf("--------------> WORD NOT FOUND <-----------------\n");
						}

						break;
					}
				case 4:
					{
						if(database)
						{
							save_database(arr);
						}
						else
						{

							printf("\nError : Database not created yet . Please create database first\n");
						}
						break;
					}
				case 5:

					{
						if(database != 1)
						{
							char file[FNAME_SIZE];
							printf("Enter the filename to update : ");
							scanf("%s",file);
							if(update_validation(arr,file) == SUCCESS)
							{
								flag = 1;
								printf("\nINFO : Updated Successfully !\n");
							}
						}
						else
						{
							printf("\nERROR : DATABASE SHOULD BE EMPTY\n");
						}
						break;
					}
				default :
					{
						printf("\nPlease enter the correct choice\n");
					}
			}

			printf("\nDo you want to continue(y/n) : ");
			scanf(" %c",&loop);
		} while(loop == 'y' || loop == 'Y');

		return 0;
	}
}

/*
void print_database(main_n **arr)
{
	for (int i = 0; i < 26; i++)
	{
		main_n *temp = arr[i];
		while (temp != NULL) 
		{
			printf("Word: %s\n", temp->word);
			printf("File Count: %d\n", temp->file_count);

			sub_n *s_temp = temp->sub_link;
			while (s_temp != NULL)
			{
				printf("File Name: %s\n", s_temp->file_name);
				printf("Word Count: %d\n", s_temp->word_count);
				s_temp = s_temp->s_link;
			}

			printf("-----------\n");

			temp = temp->main_link;
		}

	}

}*/

