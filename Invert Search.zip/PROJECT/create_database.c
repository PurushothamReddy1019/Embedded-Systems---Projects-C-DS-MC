
#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include "main.h"
char fname[FNAME_SIZE];
int create_database(Flist *f_head,main_n **arr)
{
	while(f_head != NULL)
	{

		read_filenames(f_head,arr,f_head -> f_name);
		f_head = f_head -> link;
	}

	return SUCCESS;
}

int read_filenames(Flist *f_head, main_n **arr, char *filename)
{  
	//open file in read mode

	FILE *fptr = fopen(f_head -> f_name,"r");


	if(fptr == NULL)
	{
		printf("Error in opening  file\n");
	}

	strcpy(fname,f_head -> f_name);

	char word[WORD_SIZE];

	while(fscanf(fptr,"%s",word) > 0)
	{
		int index = tolower(word[0]) % 97;

		if(!(index >= 0 && index <= 25))
			index = 26;

		if(arr[index] != NULL)
		{
			main_n *temp = arr[index];
			main_n *m_prev = NULL;

			//compare the words are equal or not
			while(temp)
			{
				if(strcmp(temp->word,word) == 0)
				{
					check_and_update_wordcount(&temp,fname);
					break;
				}
				m_prev = temp;
				temp = temp -> main_link;
			}

			if(temp == NULL)
			{
				//creating main and sub node
				main_n *m_new = malloc(sizeof(main_n));

				sub_n *s_new = malloc(sizeof(sub_n));

				if(m_new == NULL || s_new == NULL)
				{
					return FAILURE;
				}

				strcpy(m_new -> word,word);

				m_new -> file_count = 1;

				m_new -> main_link = NULL;

				s_new -> word_count = 1;

				strcpy(s_new -> file_name,fname);

				s_new -> s_link = NULL;

				m_new -> sub_link = s_new;

				if(m_prev != NULL)
				{
					m_prev -> main_link = m_new;
				}
				else
				{
					arr[index] = m_new;
				}
			}

		}

		//if arr[index] == NULL
		insert_main_node(&arr[index],word);
	}
	fclose(fptr);
	return SUCCESS;

}


int check_and_update_wordcount(main_n **head,char *filename)
{
	sub_n *s_temp = (*head) -> sub_link;

	sub_n *s_prev = NULL;

	while(s_temp)
	{
		if(strcmp(s_temp -> file_name,filename) == 0)
		{
			s_temp -> word_count++;
			return SUCCESS;
		}
		s_prev = s_temp;

		s_temp = s_temp -> s_link;
	}

	//Adding new subnode
	sub_n *new_sub = malloc(sizeof(sub_n));

	if(new_sub == NULL)
	{
		return FAILURE;
	}

	new_sub -> word_count = 1;

	strcpy(new_sub -> file_name , filename);

	new_sub -> s_link = NULL;

	if(s_prev != NULL)
	{
	s_prev -> s_link = new_sub;
	}
	else
	{
		(*head) -> sub_link = new_sub;
	}

	//increment file count
	(*head) -> file_count++;

	return SUCCESS;

}

int insert_main_node(main_n **arr, char *data)
{
	main_n *new_main =  malloc(sizeof(main_n));

	if(new_main == NULL)
	{
		return FAILURE;
	}


	new_main -> file_count = 1;

	strcpy(new_main -> word,data);

	new_main -> main_link = NULL;

	new_main -> sub_link = NULL;

	if(*arr == NULL)
	{
		*arr = new_main;
	}

	//update sub_link 
	sub_n *new_sub = malloc(sizeof(sub_n));

	if(new_sub == NULL)
	{
		return FAILURE;
	}

	new_sub -> word_count = 1;

	strcpy(new_sub -> file_name,fname);

	new_sub -> s_link = NULL;

	new_main -> sub_link = new_sub;

	return SUCCESS;
}


