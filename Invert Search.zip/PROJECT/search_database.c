#include "main.h"

int search_database(main_n *arr,char *word)
{
	if(arr == NULL)
	{
		printf("Search Word is not available in the list as list is empty\n");
		return 0;
	}

	while(arr)
	{
		if(strcmp(arr -> word,word) == 0)
		{
			printf("\nWord %s is present in %d file\n ", arr -> word , arr -> file_count);


			sub_n *s_temp = arr -> sub_link;

			while(s_temp)
			{
				printf("In File : %s\t%d times \n", s_temp -> file_name , s_temp -> word_count);
				s_temp = s_temp -> s_link;
			}
			return SUCCESS;
		}

		arr = arr -> main_link;

	}
	printf("Error: Search word is not found in list \n");	
}

