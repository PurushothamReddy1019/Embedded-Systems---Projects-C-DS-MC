#include "main.h"
int update_database(FILE *fptr , main_n *arr[27]);

int update_validation(main_n **arr , char file[50])
{
	FILE *fptr = fopen(file,"r");
	if(fptr == NULL)
	{
		perror("fopen");
		fprintf(stderr, "ERROR: Unable to open file %s\n",file);
		return FAILURE;
	}

	fseek(fptr,0,SEEK_END);

	if(ftell(fptr) == 0)
	{
		fprintf(stderr,"ERROR : File %s is an empty file\n",file);
		printf("Hence we can not update database\n");
	}
	else
	{
		if(strcmp(strstr(file,"."),".txt") != 0)
		{
			printf("FAILURE in %s: Pass .txt file\n",file);
			return FAILURE;
		}
		else
		{
			rewind(fptr);
			if(update_database(fptr,arr) == SUCCESS)
			{
				return SUCCESS;
			}
			return FAILURE;
		}
	}

}

int update_database(FILE *fptr,main_n *arr[27])
{
	char data[50];
	int index = 0;
	char word[WORD_SIZE];
	int file_count = 0;
	char file_name[FNAME_SIZE];
	int word_count = 0;
	while(fscanf(fptr,"%s", data) > 0)
	{
		if(data[0] == '#')
		{
			index = atoi(strtok(data,";"));
			strcpy(word,strtok(NULL,";"));
			file_count = atoi(strtok(NULL,";"));
			int i = file_count;

			//if the index is empty
			if(arr[index] == NULL)
			{
				main_n *m_new = malloc(sizeof(main_n));

				if(m_new == NULL)
				{
					return FAILURE;
				}

				m_new -> file_count = file_count;
				strcpy(m_new -> word,word);
				m_new -> main_link = NULL;
				m_new -> sub_link = NULL;

				strcpy(file_name,(strtok(NULL,";")));
				word_count = atoi(strtok(NULL,";"));

				sub_n *s_new = malloc(sizeof(sub_n));

				if(s_new == NULL)
				{
					return FAILURE;
				}

				strcpy(s_new -> file_name, file_name);
				s_new -> word_count = word_count;
				s_new -> s_link = NULL;
				m_new -> sub_link = s_new;

				sub_n *temp = s_new;

				while(--i)
				{
					sub_n *s_new = malloc(sizeof(sub_n));

					if(s_new == NULL)
						return FAILURE;

					strcpy(file_name,strtok(NULL,";"));
					word_count = atoi(strtok(NULL,";"));
					strcpy(s_new -> file_name , file_name);
					s_new -> word_count = word_count;
					s_new -> s_link = NULL;
					temp -> s_link = s_new;
					temp = s_new;
				}

				arr[index] = m_new;
			}
			else    // if given index is not empty
			{
				main_n *m_temp =  arr[index];
				main_n *m_prev = NULL;

				while( m_temp != NULL)
				{
					m_prev = m_temp;
					m_temp = m_temp -> main_link;
				}

				main_n *m_new = malloc(sizeof(main_n));

				if(m_new == NULL)
					return FAILURE;

				m_new -> file_count = file_count;
				strcpy(m_new -> word , word);
				m_new -> main_link = NULL;
				m_new -> sub_link = NULL;

				strcpy(file_name,strtok(NULL,";"));
				word_count = atoi(strtok(NULL,";"));

				sub_n *s_new = malloc(sizeof(sub_n));

				if(s_new == NULL)
					return FAILURE;

				strcpy(s_new -> file_name, file_name);
				s_new -> word_count = word_count;
				s_new -> s_link = NULL;
				m_new -> sub_link = s_new;

				sub_n *temp = s_new;

				while(--i)
				{
					sub_n *s_new = malloc(sizeof(sub_n));

					if(s_new == NULL)
						return FAILURE;

					strcpy(file_name,strtok(NULL,";"));
					word_count = atoi(strtok(NULL,";"));
					strcpy(s_new -> file_name , file_name);
					s_new -> word_count = word_count;
					s_new -> s_link = NULL;
					temp -> s_link = s_new;
					temp = s_new;
				}

				m_prev -> main_link = m_new;
			}


		}
		else
		{
			printf("Invalid file format\n");
			return FAILURE;
		}
	}
	return SUCCESS;



}

