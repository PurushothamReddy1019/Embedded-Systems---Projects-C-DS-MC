#include "main.h"
#include <string.h>
#include <stdlib.h>
//#include "main.c"

int file_validate_filelist(Flist **head, char *argv[])
{
	int i = 1 , check_file, flag;

	while(argv[i] != NULL)
	{
		if(strcmp(strstr(argv[i],"."),".txt") != 0)
		{
			printf("\n%s file is not .txt file\n",argv[i]);
			printf("Pass a .txt file as a input\n");
			return FAILURE;
		}
		check_file = open_files_checkfile(argv[i]);

		if(check_file == FILE_NOT_EXIST)
		{
			printf("\n%s is  not available\n",argv[i]);
			printf("Hence it is not added into list\n");
			i++;
			continue;
		}
		else if(check_file == FILE_EMPTY)
		{
			printf("\n%s has no contents\n",argv[i]);
			printf("Hence we are not adding %s into File Linked List\n", argv[i]);
			i++;
			continue;
		}
		else
		{
			flag = insert_file_list(head,argv[i]);
			if(flag == SUCCESS)
			{
				printf("\nFILE %s is Successfully added to the list\n",argv[i]);
			}
			else
			{
				printf("\n%s File is a duplicate, so not added to the list\n",argv[i]);
			}

			i++;
		}


	}
	return SUCCESS;

}

int open_files_checkfile(char *filename)
{
	FILE *fptr_fname = fopen(filename,"r");

	if(fptr_fname == NULL)
	{
		return FILE_NOT_EXIST;
	}

	fseek(fptr_fname,0,SEEK_END);

	if(ftell(fptr_fname) == 0)
	{
		fclose(fptr_fname);
		return FILE_EMPTY;
	}
	fclose(fptr_fname);
	return SUCCESS;
}

int insert_file_list(Flist **head,char *filename)
{
	Flist *temp = *head;

	while(temp != NULL)
	{
		if(strcmp(temp -> f_name,filename) == 0)
		{
			return FAILURE;
		}
		
		temp = temp -> link;
	}

	Flist *new = malloc(sizeof(Flist));

	if( new == NULL)
	{
		return FAILURE;
	}

	strcpy(new -> f_name , filename);
	new -> link = NULL;

	if(*head == NULL)
	{
		*head = new;	
		return SUCCESS;
	}

	temp = *head;

	while(temp -> link != NULL)
	{
		temp = temp -> link;
	}
	temp -> link = new;


	return SUCCESS;	
}



