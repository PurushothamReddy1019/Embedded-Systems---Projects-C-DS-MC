#include "main.h"

int display_database(main_n *h_table[])
{
	printf("------------------------------------------------------------------\n");
	printf("\n[ Index ] [ Word ] [ File count] [ Filename ] [ Word count ]\n");

	for(int i = 0 ; i < 26; i++)
	{
		main_n *m_temp = h_table[i];

		while(m_temp != NULL)
		{
			printf("[%d] [%s]\t%d file(s):\t",i, m_temp -> word, m_temp -> file_count);

			sub_n *s_temp = m_temp -> sub_link;

			while(s_temp != NULL)
			{
				printf("%s	 %d\t",s_temp -> file_name,s_temp -> word_count);

				s_temp = s_temp -> s_link;
			}
			printf("\n");

			m_temp = m_temp -> main_link;
		}
	}

	printf("\n----------------------------------------------------------------\n");

}

